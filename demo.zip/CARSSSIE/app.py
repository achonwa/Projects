from flask import Flask, render_template, request, redirect, url_for
from flask_mail import Mail, Message
from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate  # Import Flask-Migrate
from datetime import datetime, timedelta
import csv
from io import StringIO
from flask import make_response


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///staffing_agency.db'
db = SQLAlchemy(app)
mail = Mail(app)


@app.route("/")
def home():
    return render_template("index.html")

@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/departments")
def departments():
    return render_template("departments.html")

@app.route("/doctors")
def doctors():
    return render_template("doctors.html")

@app.route("/contact")
def contactus():
    return render_template("contact.html")

# Configure mail settings
app.config['MAIL_SERVER'] = 'smtp.example.com'  # Replace with your mail server
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'your-email@example.com'  # Replace with your email
app.config['MAIL_PASSWORD'] = 'your-password'  # Replace with your email password
migrate = Migrate(app, db)  # Initialize Flask-Migrate

# Staff Model
class Staff(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    number = db.Column(db.String(15), nullable=False)
    address = db.Column(db.String(200), nullable=False)
    position = db.Column(db.String(100), nullable=False)
    work_hours = db.Column(db.Float, nullable=False)  # Corrected typo: work_hours
    payment_date = db.Column(db.String(10), nullable=False)
    salary = db.Column(db.Float, nullable=False)
    bi_weekly_sequence = db.Column(db.Integer, nullable=False)  # New column

# Business Expenses Model
class BusinessExpenses(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    logistics = db.Column(db.Float, nullable=False)
    accommodation = db.Column(db.Float, nullable=False)
    mercaleanos_bills = db.Column(db.Float, nullable=False)
    date = db.Column(db.String(10), nullable=False)
    bi_weekly_sequence = db.Column(db.Integer, nullable=False)  # New column

# Helper function to calculate the current bi-weekly sequence
def get_current_bi_weekly_sequence():
    start_date = datetime(2023, 1, 1)
    today = datetime.today()
    delta = today - start_date
    return (delta.days // 14) + 1

@app.route('/record')
def record():
    current_sequence = get_current_bi_weekly_sequence()
    staff_list = Staff.query.filter_by(bi_weekly_sequence=current_sequence).all()
    expenses_list = BusinessExpenses.query.filter_by(bi_weekly_sequence=current_sequence).all()
    total_salary = sum(staff.salary for staff in staff_list)
    total_expenses = sum(expense.logistics + expense.accommodation + expense.mercaleanos_bills for expense in expenses_list)
    net_earnings = total_salary - total_expenses
    all_sequences = db.session.query(Staff.bi_weekly_sequence).union(db.session.query(BusinessExpenses.bi_weekly_sequence)).distinct().all()
    all_sequences = [seq[0] for seq in all_sequences]
    return render_template('record.html', staff_list=staff_list, total_salary=total_salary, expenses_list=expenses_list, total_expenses=total_expenses, net_earnings=net_earnings, current_sequence=current_sequence, all_sequences=all_sequences)

@app.route('/add_staff', methods=['GET', 'POST'])
def add_staff():
    if request.method == 'POST':
        name = request.form['name']
        number = request.form['number']
        address = request.form['address']
        position = request.form['position']
        work_hours = float(request.form['work_hours'])
        payment_date = request.form['payment_date']
        salary = float(request.form['salary'])
        bi_weekly_sequence = get_current_bi_weekly_sequence()

        new_staff = Staff(name=name, number=number, address=address, position=position, work_hours=work_hours, payment_date=payment_date, salary=salary, bi_weekly_sequence=bi_weekly_sequence)
        db.session.add(new_staff)
        db.session.commit()
        return redirect(url_for('record'))
    return render_template('add_staff.html')

@app.route('/add_expense', methods=['GET', 'POST'])
def add_expense():
    if request.method == 'POST':
        logistics = float(request.form['logistics'])
        accommodation = float(request.form['accommodation'])
        mercaleanos_bills = float(request.form['mercaleanos_bills'])
        date = request.form['date']
        bi_weekly_sequence = get_current_bi_weekly_sequence()

        new_expense = BusinessExpenses(logistics=logistics, accommodation=accommodation, mercaleanos_bills=mercaleanos_bills, date=date, bi_weekly_sequence=bi_weekly_sequence)
        db.session.add(new_expense)
        db.session.commit()
        return redirect(url_for('record'))
    return render_template('add_expense.html')

@app.route('/view_sequence/<int:sequence>')
def view_sequence(sequence):
    staff_list = Staff.query.filter_by(bi_weekly_sequence=sequence).all()
    expenses_list = BusinessExpenses.query.filter_by(bi_weekly_sequence=sequence).all()
    total_salary = sum(staff.salary for staff in staff_list)
    total_expenses = sum(expense.logistics + expense.accommodation + expense.mercaleanos_bills for expense in expenses_list)
    net_earnings = total_salary - total_expenses
    return render_template('view_sequence.html', staff_list=staff_list, total_salary=total_salary, expenses_list=expenses_list, total_expenses=total_expenses, net_earnings=net_earnings, sequence=sequence)

@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        try:
            name = request.form.get('name')
            email = request.form.get('email')
            subject = request.form.get('subject')
            message_body = request.form.get('message')

            if not all([name, email, subject, message_body]):
                return render_template('contact.html', error='All fields are required.')

            msg = Message(subject=f"[Contact Form] {subject}",
                          recipients=['contact@example.com'])  # Replace with your receiving email

            msg.body = f"""
            You have received a new message from your website contact form.

            From: {name}
            Email: {email}

            Message:
            {message_body}
            """

            mail.send(msg)

            return render_template('contact.html', success='Your message has been sent successfully!')

        except Exception as e:
            return render_template('contact.html', error=f'An error occurred: {str(e)}')

    return render_template('contact.html')


@app.route('/download_csv')
def download_csv():
    # Query all staff records
    staff_list = Staff.query.all()

    # Create a StringIO object to write CSV data to memory
    si = StringIO()
    writer = csv.writer(si)

    # Write the CSV headers (adjust these fields as needed)
    writer.writerow(['ID', 'Name', 'Number', 'Address', 'Position', 'Work Hours', 'Payment Date', 'Salary', 'Bi-Weekly Sequence'])

    # Write each row of data
    for staff in staff_list:
        writer.writerow([
            staff.id,
            staff.name,
            staff.number,
            staff.address,
            staff.position,
            staff.work_hours,
            staff.payment_date,
            staff.salary,
            staff.bi_weekly_sequence
        ])

    # Prepare response to send the CSV as an attachment
    response = make_response(si.getvalue())
    response.headers['Content-Disposition'] = 'attachment; filename=staff_records.csv'
    response.headers['Content-type'] = 'text/csv'

    return response



if __name__ == '__main__':
    app.run(debug=True)